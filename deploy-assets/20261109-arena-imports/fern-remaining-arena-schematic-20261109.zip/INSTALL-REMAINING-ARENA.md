# Fern remaining arena schematic

`by-kubj-lobby-japan-free.schem` is a WorldEdit/FAWE schematic, not a complete Minecraft world. It is approximately 201 x 249 x 240 blocks and must be pasted into an existing loaded arena dimension.

## Recommended destination

Use it as the lobby/building for `forge_combiroll_arena`. The Sakura Spawn package is already intended for `forge_class_arena`. Do not paste this into the main survival world.

## Requirements

Install a Minecraft 26.3-compatible Fabric build of WorldEdit or FAWE in the server `mods` directory. Do not install both at the same time. Restart the server after adding it.

Copy the schematic to the server's WorldEdit schematics directory. Depending on the WorldEdit build, this is usually:

`config/worldedit/schematics/`

or:

`plugins/WorldEdit/schematics/`

## Paste procedure

1. Enter `forge_combiroll_arena` first, or create/load that arena dimension.
2. Make a backup before pasting.
3. Stand at the desired lobby origin.
4. Use WorldEdit to load the schematic:

`//schem load by-kubj-lobby-japan-free`

5. Preview the paste with:

`//paste -preview`

6. If the preview is correct, paste without entities first:

`//paste -e`

7. Save the world and restart the server after confirming the build.

The schematic contains block entities such as containers or decorative data. Inspect them before enabling public access. Never paste an untrusted schematic near the survival spawn.

## Important

A schematic does not create `forge_combiroll_arena`. The arena dimension must already exist and be loaded. The Fern mod can teleport to loaded dimensions, but it does not create dimensions or paste WorldEdit schematics automatically.
