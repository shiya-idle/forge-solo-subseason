# Fern class arena import

This package uses the uploaded Sakura Spawn Java world as the terrain for Fern's `fern:forge_class_arena` dimension. It does not replace the main world.

1. Stop the Minecraft service.
2. Back up the current server world folder.
3. Open the server's active world folder. The default is usually `/home/ubuntu/fern-server/world`, but confirm `level-name` in `server.properties` first.
4. Copy the included `world/datapacks/fern-arenas` directory into the active world folder's `datapacks` directory.
5. Copy the included `world/dimensions/fern/forge_class_arena/region` directory into the active world folder's `dimensions/fern/forge_class_arena/region` directory.
6. Start the server. A full restart is required; `/reload` is not enough for a new dimension.
7. Test with `/waypoint class-001` or `/execute in fern:forge_class_arena run tp @s 0 80 0`.

The Fern mod searches by dimension path, so `fern:forge_class_arena` matches the configured `forge_class_arena` destination. The existing class-001 waypoint is near the arena center.

Do not copy the uploaded `level.dat`, `level.dat_old`, `uid.dat`, or `session.lock` into the active world. Do not replace the main `world` folder.

The source also included `SakuraSpawn.schematic`. It is not required for this import because the complete region files are included.
