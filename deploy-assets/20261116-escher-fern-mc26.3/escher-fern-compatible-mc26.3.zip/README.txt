The Escher Dimension — Fern-compatible port for Minecraft Java 26.3
Original datapack by ZungryWare; see credits.txt and UPSTREAM-README-1.16.5.txt.
Install alongside Forge Solo Subseason 26.3; see FERN-COMPATIBILITY.md.
The server requires enable-command-block=true per the upstream instructions.
See PORT-VALIDATION-26.3.md for static audit and staging status; full dungeon progression still needs in-game testing.
