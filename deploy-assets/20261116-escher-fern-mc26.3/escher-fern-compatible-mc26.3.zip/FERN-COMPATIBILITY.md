# Fern / Escher compatibility (Minecraft Java 26.3)

This port is designed to run beside Forge Solo Subseason on Fabric. The `tid:` namespace remains intact, so Escher resources do not replace Fern's `forge_*` arenas or `fern` dimension.

## Player entry and return

With the compatible Fern mod JAR installed, players can run `/waypoint dungeon` (alias `/waypoint escher`) to enter `tid:layer_1` at the Escher start platform, `(0, 55, 0)`. The datapack pre-carves the protected Layer 1 landing chamber during load, before a waypoint can place a player inside flat stone. Fern tracks each player's last Overworld position every 10 server ticks while they are online and provides `/fern return last` or `/fern return spawn`; the last-position map is in memory and resets on server restart. Escher no longer redirects players out of vanilla dimensions on every tick. The waypoint reports a clear error if Layer 1 is not loaded.

Portal routing uses stable `tid_portal_color_N` identity tags and a generic `tid_portal_marker` tag rather than custom-name selectors. Newly summoned and structure-loaded markers receive both tags at creation. Existing worlds with already-spawned untagged markers require affected markers to be rebuilt or manually retagged from a verified destination-color mapping before upgrade: the 26.3 live probe found the legacy `Color` field missing, so name-only automatic migration is unsafe. A per-player `tid_portal_contact` latch is set before transfer and cleared after the player leaves the sea-lantern floor, preventing repeated activation while standing on or immediately arriving at a portal.

## Fern gameplay hooks

Fern's owner-binding applies in Escher dimensions just as it does elsewhere: carried and crafted stacks are bound to their player outside Cornucopia, and the Escher Delver daily quest counts monster kills in any `tid:` dimension. The init function explicitly sets `keep_inventory false` so Fern can retain its permanent, owner-locked death drops and coordinate notices. This is a server-wide rule and is intentional for the requested Fern death behavior.

The upstream `setworldspawn` call was removed to preserve the Fern server's existing Overworld spawn. Escher's unrelated global gamerule overrides for weather, phantoms, raids, patrols, traders, and command feedback were also removed. The upstream command-sequence limit is retained because procedural generation uses long function chains.

## Install / operational notes

1. Use Minecraft 26.3, Fabric, Java 25, and enable `enable-command-block=true` in `server.properties`.
2. Install the matching Forge Solo Subseason Fabric JAR in `mods/`.
3. Install this datapack in the active world's `datapacks/` directory, then fully restart the server so the `tid:` dimensions register.
4. Back up the world first. See `PORT-VALIDATION-26.3.md`, `FUNCTION-REPAIRS-26.3.md`, and `RUNTIME-VALIDATION-26.3.md`: active missing calls are repaired, portal dispatch uses stable tags, but already-spawned untagged portal markers must be rebuilt or manually retagged from a verified destination-color mapping because Minecraft 26.3 did not retain legacy `Color` in the live entity probe; no automatic migration is attempted. Active custom-name portal selectors are removed. The integrated Fabric/26.3 startup plus representative function smoke calls passed. Run a player-driven portal walk-through before production; rerun the previously passed Layer 1 landing and `/fern return spawn` / `/fern return last` checks as regressions.
