# Escher + Fern runtime validation, Minecraft 26.3

Validation date: 2026-11-16. Environment: Fabric Loom 1.18.4, Fabric Loader 0.19.5, Minecraft 26.3, Java 25.0.5+8, and the Forge Solo Subseason Fabric mod.

## Passed checks

- `:platform-fabric:build` completed successfully.
- The integrated `:platform-fabric:runServer` cold boot reached the server-ready `Done` marker; Fern initialized and all `tid:layer_*` dimensions registered.
- The pack audit found zero unresolved active `tid:` function targets, and the server log contained no datapack/function parse failures.
- Representative smoke calls to `tid:custom_mobs/war_pig`, `tid:dungeon/sand1/build_hall_south`, `tid:dungeon/sand2/build_hall_east`, and `tid:dungeon/station/generate_straggler_execute` ran without command errors.
- The disposable server was stopped cleanly.

## Escher random-generation integration patch (2026-11-22)
- A fresh disposable Fabric 26.3 / Fabric Loader 0.19.5 world auto-loaded the patched ZIP and loaded `tid:main` with no function parse errors. After setting `(-6, 182, -6)` to bedrock and invoking `function tid:main`, a block-state scoreboard check confirmed sea lantern. The server shut down cleanly. This is a command-level smoke test, not connected-player portal traversal.
- Wan’er’s preceding staging pass succeeded for the Layer 1 landing and `/fern return spawn` / `/fern return last`; keep these as regression checks for the next playtest.

- The runtime patcher tags all 16 teleporter summon sites and 8 structure portal markers with stable color and generic marker tags. A disposable live probe found that a legacy-style entity retained its exact `CustomName` but not its old `Color` NBT in Minecraft 26.3, so automatic identity migration would not be reliable. Existing untagged markers must be rebuilt or manually retagged from a verified destination-color mapping before upgrade. Normal routing uses stable tags; active custom-name selectors are removed, and a contact latch prevents repeat transfers.
- A disposable live probe confirmed that an area-effect cloud summoned with the legacy portal name retains the exact `CustomName` in 26.3, but the old `Color` field is missing (`data get entity @s Color` fails); the marker therefore cannot be assigned a destination identity automatically. No unsafe name-only migration is shipped. Existing untagged markers must be rebuilt or manually retagged from a verified destination-color mapping before upgrade.
- After all portal dispatch/build calls, the main tick repairs the reachable Hellion color-1 return approach at `(-6, 182, -6)`, directly under the marker at `(-6, 183, -6)` and within the active trigger's 3-block radius. It replaces the tile with sea lantern only when it is bedrock, so portal contact latching is unchanged and `teleporter_build` cannot overwrite the repair. Static regression coverage is added; rerun the player-driven two-way walk-through in a fresh disposable world.
- The Fabric module build passed after adding Overworld return-position tracking every 10 server ticks and checking teleport success before reporting a return. The last-Overworld-position map is in memory and is not persisted across server restarts.

## Scope limit
These automated checks cover startup/parser, representative calls, and static integration checks; they are not a full player-driven dungeon run. A player-driven portal walk-through is still needed to confirm destination arrival, no immediate bounce-back, and walking back through a portal. The preceding staging pass succeeded for the Layer 1 landing and `/fern return spawn` / `/fern return last`; rerun these as regression checks. Procedural room connectivity, progression, every random branch, balance, and long-run performance also need disposable staging playtests. Non-blocking unrelated notices observed were vanilla piglin-barter loot-table parameter warnings and Fabric untranslated item-tag warnings.


