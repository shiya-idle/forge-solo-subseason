#Carve
setblock ~ ~ ~ minecraft:structure_block[mode=load]{name: "tid:finale/cave_1", posX: -6, posY: -7, posZ: -6, ignoreEntities: 0b, powered: 0b, showair: 0b, showboundingbox: 0b}
setblock ~ ~1 ~ redstone_block
