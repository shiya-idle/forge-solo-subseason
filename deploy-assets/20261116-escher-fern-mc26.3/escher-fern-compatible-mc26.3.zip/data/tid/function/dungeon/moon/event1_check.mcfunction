#Always generate at least two, and keep them far apart
execute if score moon_rooms value matches ..400 unless score infernal_portals value matches 2.. unless entity @e[type=area_effect_cloud,distance=0..30,tag=tid_portal_color_4] run function tid:dungeon/moon/event1_generate

#Others can also generate at random
execute if predicate tid:random_02 unless entity @e[type=area_effect_cloud,distance=0..30,tag=tid_portal_color_4] run function tid:dungeon/moon/event1_generate
