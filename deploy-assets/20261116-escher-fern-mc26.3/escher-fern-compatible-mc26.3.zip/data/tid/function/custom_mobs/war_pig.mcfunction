# Weighted tier roll: low 50%, medium 25%, high 12.5%, super 12.5%.
scoreboard players set temp2 value 0
execute if score temp2 value matches 0 if predicate tid:random_50 run scoreboard players set temp2 value 1
execute if score temp2 value matches 0 if predicate tid:random_50 run scoreboard players set temp2 value 2
execute if score temp2 value matches 0 if predicate tid:random_50 run scoreboard players set temp2 value 3
execute if score temp2 value matches 0 run scoreboard players set temp2 value 4
execute if score temp2 value matches 1 run function tid:custom_mobs/war_pig_1
execute if score temp2 value matches 2 run function tid:custom_mobs/war_pig_2
execute if score temp2 value matches 3 run function tid:custom_mobs/war_pig_3
execute if score temp2 value matches 4 run function tid:custom_mobs/war_pig_4
